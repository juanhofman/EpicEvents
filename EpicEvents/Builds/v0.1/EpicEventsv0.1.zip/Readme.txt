Thanks for participating in the public alpha!

Required dependencies
	- Stop The Ped (bejoijo)
	- Ultimate backup (bejoijo)

Please read the rest of the readme to get an understanding of this plugin.

If you encounter any bugs, please report them at the following form: https://forms.gle/3GDMRAP9Lzmqijvh6

-- EPIC EVENTS (public alpha) --

At epic events current state certain variables are hard coded, this will change at a later state. 
Examples are: Max and minimal time between events. When a event occurs a blip will be visible on the minimap.

Keybind:
	- End: stop the event and restart generation.

Current events:
	- Homeless disturbance.
	- Drug deal.


Plans for v0.2:
	- Shots fired.
	- Car alarm.
